#!/usr/bin/env python3
"""Small expressive motion sequencer for head and arms."""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

import rclpy
from builtin_interfaces.msg import Duration
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


class ExpressiveMotion(Node):
    """Publishes periodic joint goals to make the simulated robot feel alive."""

    def __init__(self) -> None:
        super().__init__('walle_expressive_motion')

        self.declare_parameter('head_topic', '/head_controller/joint_trajectory')
        self.declare_parameter('arm_topic', '/arm_controller/joint_trajectory')
        self.declare_parameter('period_sec', 3.0)

        head_topic = self.get_parameter('head_topic').get_parameter_value().string_value
        arm_topic = self.get_parameter('arm_topic').get_parameter_value().string_value
        period_sec = float(self.get_parameter('period_sec').value)

        self.head_pub = self.create_publisher(JointTrajectory, head_topic, 10)
        self.arm_pub = self.create_publisher(JointTrajectory, arm_topic, 10)

        self.head_poses: List[Tuple[float, float]] = [
            (0.55, -0.08),
            (-0.50, 0.05),
            (0.00, -0.18),
            (0.35, 0.10),
        ]
        self.arm_poses: List[Tuple[float, float]] = [
            (0.40, -0.40),
            (0.15, -0.15),
            (0.52, -0.52),
            (0.20, -0.20),
        ]
        self.index = 0

        # Small startup delay helps when controllers are still activating.
        self.startup_timer = self.create_timer(1.5, self.start_sequence)
        self.period_sec = max(period_sec, 1.0)
        self.motion_timer = None

        self.get_logger().info('Expressive motion node started.')

    def start_sequence(self) -> None:
        if self.startup_timer is not None:
            self.startup_timer.cancel()
            self.startup_timer = None
        self.publish_current_pose()
        self.motion_timer = self.create_timer(self.period_sec, self.publish_current_pose)

    def publish_current_pose(self) -> None:
        head = self.head_poses[self.index % len(self.head_poses)]
        arms = self.arm_poses[self.index % len(self.arm_poses)]

        self.publish_trajectory(
            publisher=self.head_pub,
            joint_names=['head_yaw_joint', 'head_pitch_joint'],
            positions=head,
            duration_sec=1.2,
        )
        self.publish_trajectory(
            publisher=self.arm_pub,
            joint_names=['left_arm_joint', 'right_arm_joint'],
            positions=arms,
            duration_sec=1.4,
        )

        self.index += 1

    def publish_trajectory(
        self,
        publisher,
        joint_names: Sequence[str],
        positions: Sequence[float],
        duration_sec: float,
    ) -> None:
        msg = JointTrajectory()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.joint_names = list(joint_names)

        point = JointTrajectoryPoint()
        point.positions = [float(v) for v in positions]
        point.time_from_start = Duration(sec=int(duration_sec), nanosec=int((duration_sec % 1.0) * 1e9))

        msg.points = [point]
        publisher.publish(msg)


def main(args: Optional[List[str]] = None) -> None:
    rclpy.init(args=args)
    node = ExpressiveMotion()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
