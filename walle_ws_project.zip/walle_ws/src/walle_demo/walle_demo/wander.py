#!/usr/bin/env python3
"""Reactive obstacle-avoidance wander controller for the WALL-E inspired robot."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import List, Optional

import rclpy
from geometry_msgs.msg import TwistStamped
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import LaserScan


@dataclass
class ScanState:
    ranges: List[float]
    angle_min: float
    angle_increment: float
    range_min: float
    range_max: float


class ReactiveWander(Node):
    """Drive forward when clear and turn away from nearby obstacles."""

    def __init__(self) -> None:
        super().__init__('walle_reactive_wander')

        self.declare_parameter('cmd_topic', '/diff_drive_base_controller/cmd_vel')
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('safe_distance', 0.65)
        self.declare_parameter('cruise_speed', 0.22)
        self.declare_parameter('turn_speed', 1.05)
        self.declare_parameter('control_rate_hz', 10.0)

        cmd_topic = self.get_parameter('cmd_topic').get_parameter_value().string_value
        scan_topic = self.get_parameter('scan_topic').get_parameter_value().string_value
        self.safe_distance = float(self.get_parameter('safe_distance').value)
        self.cruise_speed = float(self.get_parameter('cruise_speed').value)
        self.turn_speed = float(self.get_parameter('turn_speed').value)
        control_rate_hz = float(self.get_parameter('control_rate_hz').value)

        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
        )

        self.cmd_pub = self.create_publisher(TwistStamped, cmd_topic, 10)
        self.scan_sub = self.create_subscription(LaserScan, scan_topic, self.scan_callback, qos)
        self.timer = self.create_timer(1.0 / max(control_rate_hz, 1.0), self.control_loop)

        self.scan_state: Optional[ScanState] = None
        self.turn_until = self.get_clock().now()
        self.turn_direction = 1.0
        self.bias = 0.0
        self.last_log_time = self.get_clock().now()

        self.get_logger().info('Reactive wander node started.')

    def scan_callback(self, msg: LaserScan) -> None:
        self.scan_state = ScanState(
            ranges=list(msg.ranges),
            angle_min=msg.angle_min,
            angle_increment=msg.angle_increment,
            range_min=msg.range_min,
            range_max=msg.range_max,
        )

    def control_loop(self) -> None:
        if self.scan_state is None:
            # No scan yet: rotate slowly to make it obvious the robot is alive.
            self.publish_cmd(0.0, 0.35)
            return

        now = self.get_clock().now()
        if now < self.turn_until:
            self.publish_cmd(0.0, self.turn_direction * self.turn_speed)
            return

        front = self.sector_min(-0.30, 0.30)
        left = self.sector_min(0.30, 1.20)
        right = self.sector_min(-1.20, -0.30)

        if front < self.safe_distance:
            # Turn toward the more open side for a randomized duration.
            self.turn_direction = 1.0 if left > right else -1.0
            duration_sec = random.uniform(0.9, 1.6)
            self.turn_until = now + Duration(seconds=duration_sec)
            self.bias = random.uniform(-0.12, 0.12)
            self.publish_cmd(0.0, self.turn_direction * self.turn_speed)
            self.maybe_log(
                f'Obstacle ahead (front={front:.2f} m). Turning '
                f'{"left" if self.turn_direction > 0 else "right"} for {duration_sec:.2f}s.'
            )
            return

        # Open space: move forward and gently steer away from the closer side.
        corridor_balance = self.normalize_range(right) - self.normalize_range(left)
        angular = 0.8 * corridor_balance + self.bias
        angular = max(min(angular, 0.65), -0.65)

        linear = self.cruise_speed
        if front < self.safe_distance * 1.6:
            linear *= 0.6
        if min(left, right) < self.safe_distance * 0.8:
            linear *= 0.75

        # Slowly vary behavior so the path looks more natural.
        self.bias *= 0.98
        if random.random() < 0.03:
            self.bias = random.uniform(-0.18, 0.18)

        self.publish_cmd(linear, angular)

    def sector_min(self, angle_start: float, angle_end: float) -> float:
        assert self.scan_state is not None

        state = self.scan_state
        if not state.ranges:
            return state.range_max

        index_start = int((angle_start - state.angle_min) / state.angle_increment)
        index_end = int((angle_end - state.angle_min) / state.angle_increment)

        index_start = max(0, min(index_start, len(state.ranges) - 1))
        index_end = max(0, min(index_end, len(state.ranges) - 1))
        if index_start > index_end:
            index_start, index_end = index_end, index_start

        valid = []
        for value in state.ranges[index_start:index_end + 1]:
            if math.isfinite(value) and state.range_min < value < state.range_max:
                valid.append(value)

        if not valid:
            return state.range_max
        return min(valid)

    @staticmethod
    def normalize_range(value: float, clip_max: float = 2.5) -> float:
        value = min(max(value, 0.0), clip_max)
        return value / clip_max

    def publish_cmd(self, linear_x: float, angular_z: float) -> None:
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_footprint'
        msg.twist.linear.x = float(linear_x)
        msg.twist.angular.z = float(angular_z)
        self.cmd_pub.publish(msg)

    def maybe_log(self, text: str) -> None:
        now = self.get_clock().now()
        if (now - self.last_log_time).nanoseconds > 2_000_000_000:
            self.get_logger().info(text)
            self.last_log_time = now


def main(args: Optional[List[str]] = None) -> None:
    rclpy.init(args=args)
    node = ReactiveWander()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.publish_cmd(0.0, 0.0)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
