from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction, RegisterEventHandler
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, FindExecutable, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time')
    start_demo = LaunchConfiguration('start_demo')
    x = LaunchConfiguration('x')
    y = LaunchConfiguration('y')
    z = LaunchConfiguration('z')

    controllers_file = PathJoinSubstitution([
        FindPackageShare('walle_bringup'),
        'config',
        'controllers.yaml',
    ])

    bridge_file = PathJoinSubstitution([
        FindPackageShare('walle_bringup'),
        'config',
        'bridge.yaml',
    ])

    world_file = PathJoinSubstitution([
        FindPackageShare('walle_bringup'),
        'worlds',
        'walle_arena.sdf',
    ])

    xacro_file = PathJoinSubstitution([
        FindPackageShare('walle_description'),
        'urdf',
        'walle.urdf.xacro',
    ])

    robot_description_content = Command([
        PathJoinSubstitution([FindExecutable(name='xacro')]),
        ' ', xacro_file,
        ' ', 'controllers_file:=', controllers_file,
    ])

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            {'robot_description': robot_description_content},
        ],
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('ros_gz_sim'),
                'launch',
                'gz_sim.launch.py',
            ])
        ]),
        launch_arguments={'gz_args': [' -r -v 2 ', world_file]}.items(),
    )

    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        output='screen',
        arguments=[
            '-topic', 'robot_description',
            '-name', 'walle',
            '-x', x,
            '-y', y,
            '-z', z,
            '-allow_renaming', 'false',
        ],
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        output='screen',
        parameters=[
            {'config_file': bridge_file},
        ],
    )

    joint_state_broadcaster = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster'],
        output='screen',
    )

    diff_drive_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['diff_drive_base_controller', '--param-file', controllers_file],
        output='screen',
    )

    head_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['head_controller', '--param-file', controllers_file],
        output='screen',
    )

    arm_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['arm_controller', '--param-file', controllers_file],
        output='screen',
    )

    wander_node = Node(
        package='walle_demo',
        executable='wander',
        output='screen',
        condition=IfCondition(start_demo),
        parameters=[{'use_sim_time': use_sim_time}],
    )

    expressive_node = Node(
        package='walle_demo',
        executable='expressive',
        output='screen',
        condition=IfCondition(start_demo),
        parameters=[{'use_sim_time': use_sim_time}],
    )

    launch_items = [
        DeclareLaunchArgument('use_sim_time', default_value='true', description='Use Gazebo clock'),
        DeclareLaunchArgument('start_demo', default_value='false', description='Start reactive wandering + expressive joints'),
        DeclareLaunchArgument('x', default_value='0.0', description='Initial X position'),
        DeclareLaunchArgument('y', default_value='0.0', description='Initial Y position'),
        DeclareLaunchArgument('z', default_value='0.25', description='Initial Z position'),
        robot_state_publisher,
        gazebo,
        bridge,
        spawn_entity,
        RegisterEventHandler(
            OnProcessExit(
                target_action=spawn_entity,
                on_exit=[joint_state_broadcaster],
            )
        ),
        RegisterEventHandler(
            OnProcessExit(
                target_action=joint_state_broadcaster,
                on_exit=[diff_drive_controller, head_controller, arm_controller, wander_node, expressive_node],
            )
        ),
    ]

    return LaunchDescription(launch_items)
